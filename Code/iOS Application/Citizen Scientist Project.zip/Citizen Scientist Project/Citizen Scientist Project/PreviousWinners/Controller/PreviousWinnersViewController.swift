//
//  PreviousWinnersViewController.swift
//  Citizen-Scientist-Project
//
//  Created by David Gonzalez on 4/4/18.
//  Copyright © 2018 Key Biscayne. All rights reserved.
//

import UIKit

class PreviousWinnersViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        ReusableHeader.setUpNavBar(navigationController: self.navigationController, navigationItem: self.navigationItem)
    }

}
