//
//  Citizen_Scientist_ProjectTests.swift
//  Citizen Scientist ProjectTests
//
//  Created by David Gonzalez on 1/31/18.
//  Copyright © 2018 Key Biscayne. All rights reserved.
//

import XCTest
@testable import Citizen_Scientist_Project

class Citizen_Scientist_ProjectTests: XCTestCase {
    
    // Initial commit
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
